package com.shai.calculatorappp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1EditText = findViewById(R.id.num1editTextNumber)
        num2EditText = findViewById(R.id.num2editTextNumber)
        resultTextView = findViewById(R.id.editTextNumber)

        val addButton = findViewById<Button>(R.id.buttonPlus)
        val subtractButton = findViewById<Button>(R.id.buttonMinus)
        val multiplyButton = findViewById<Button>(R.id.buttonMultiply)
        val divideButton = findViewById<Button>(R.id.buttonDivide)

        addButton.setOnClickListener { performCalculation("+") }
        subtractButton.setOnClickListener { performCalculation("-") }
        multiplyButton.setOnClickListener { performCalculation("*") }
        divideButton.setOnClickListener { performCalculation("/") }
    }

    private fun performCalculation(operation: String) {
        val num1 = num1EditText.text.toString().toIntOrNull() ?: return
        val num2 = num2EditText.text.toString().toIntOrNull() ?: return

        val result = when (operation) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0) num1 / num2.toDouble() else Double.NaN
            else -> Double.NaN
        }

        resultTextView.text = "Result: $num1 $operation $num2 = $result"
    }
}