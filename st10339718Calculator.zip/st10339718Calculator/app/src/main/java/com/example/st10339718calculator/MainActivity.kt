package com.example.st10339718calculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private lateinit var input1: EditText
    private lateinit var input2: EditText
    private lateinit var operationResult: TextView
    private val numberArray = IntArray(10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input1 = findViewById(R.id.editTextNumber1)
        input2 = findViewById(R.id.editTextNumber2)
        operationResult = findViewById(R.id.textViewResult)
    }

    fun performOperation(view: View) {
        val num1 = input1.text.toString().toDouble()
        val num2 = input2.text.toString().toDouble()

        when (view.id) {
            R.id.buttonAddition -> displayResult("$num1 + $num2 = ${num1 + num2}")
            R.id.buttonSubtraction -> displayResult("$num1 - $num2 = ${num1 - num2}")
            R.id.buttonMultiplication -> displayResult("$num1 * $num2 = ${num1 * num2}")
            R.id.buttonDivision -> {
                if (num2 != 0.0) {
                    displayResult("$num1 / $num2 = ${num1 / num2}")
                } else {
                    displayResult("Error: Division by 0 is undefined")
                }
            }
            R.id.buttonSquareRoot -> {
                if (num1 >= 0) {
                    displayResult("sqrt($num1) = ${sqrt(num1)}")
                } else {
                    displayResult("sqrt($num1) = {sprt(abs($num1))}i")
                }
            }
            R.id.buttonPower -> displayResult("$num1^$num2 = ${num1.pow(num2)}")
        }
    }

    fun clearArray(view: View) {
        numberArray.fill(0)
        operationResult.text = "Array cleared."
    }

    fun calculateAverage(view: View) {
        val sum = numberArray.sum()
        val average = if (numberArray.isNotEmpty()) sum.toDouble() / numberArray.size else 0.0
        operationResult.text = "Average: $average"
    }

    fun findMinMax(view: View) {
        val min = numberArray.minOrNull()
        val max = numberArray.maxOrNull()
        operationResult.text = "Min: $min, Max: $max"
    }

    private fun displayResult(result: String) {
        operationResult.text = result
    }
}

