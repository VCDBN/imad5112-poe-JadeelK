package com.example.st10339718calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatsActivity1 : AppCompatActivity() {
    lateinit var displayResult: TextView
    lateinit var editTextArrayInput: EditText
    lateinit var buttonStoreArray: Button
    lateinit var buttonClearArray: Button
    lateinit var buttonCalculateAverage: Button
    lateinit var buttonFindMinMax: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        displayResult = findViewById(R.id.textViewStatResult)
        editTextArrayInput = findViewById(R.id.editTextArrayInput)
        buttonStoreArray = findViewById(R.id.buttonStoreArray)
        buttonClearArray = findViewById(R.id.buttonClearArray)
        buttonCalculateAverage = findViewById(R.id.buttonCalculateAverage)
        buttonFindMinMax = findViewById(R.id.buttonFindMinMax)

        buttonStoreArray.setOnClickListener {
            // Handle the button click for storing the array
            // For example, you can retrieve the entered text from editTextArrayInput
            val userInput = editTextArrayInput.text.toString()
            // Process the user input as needed
        }

        buttonClearArray.setOnClickListener {
            // Handle the button click for clearing the array or any other action
        }

        buttonCalculateAverage.setOnClickListener {
            // Handle the button click for calculating average or any other action
        }

        buttonFindMinMax.setOnClickListener {
            // Handle the button click for finding Min/Max or any other action
        }
    }
}
